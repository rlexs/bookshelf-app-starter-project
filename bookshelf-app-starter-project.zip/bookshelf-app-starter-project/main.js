document.addEventListener("DOMContentLoaded", function () {
  const RENDER_EVENT = "render-book";

  const incompleteBookList = document.getElementById("incompleteBookList");
  const completeBookList = document.getElementById("completeBookList");

  // Fungsi untuk menyimpan buku ke localStorage
  function saveBooksToStorage() {
    localStorage.setItem("books", JSON.stringify(books));
  }

  // Fungsi untuk mengambil buku dari localStorage
  function loadBooksFromStorage() {
    const serializedBooks = localStorage.getItem("books");
    return serializedBooks ? JSON.parse(serializedBooks) : [];
  }

  // Inisialisasi daftar buku dari localStorage
  const books = loadBooksFromStorage();

  // Fungsi untuk membuat ID buku
  function generateId() {
    return +new Date();
  }

  // Fungsi untuk membuat objek buku
  function generateBookObject(id, title, author, year, isComplete) {
    return {
      id,
      title,
      author,
      year: parseInt(year),
      isComplete,
    };
  }

  // Fungsi untuk menambahkan buku baru
  function addBook() {
    const bookFormTitle = document.getElementById("bookFormTitle").value;
    const bookFormAuthor = document.getElementById("bookFormAuthor").value;
    const bookFormYear = document.getElementById("bookFormYear").value;
    const bookFormIsComplete = document.getElementById("bookFormIsComplete").checked;

    const generatedID = generateId();
    const bookObject = generateBookObject(
      generatedID,
      bookFormTitle,
      bookFormAuthor,
      bookFormYear,
      bookFormIsComplete
    );

    books.push(bookObject);
    saveBooksToStorage(); // Simpan data ke localStorage

    document.dispatchEvent(new Event(RENDER_EVENT));
  }

  // Fungsi untuk membuat elemen buku
  function makeBook(bookObject) {
    const bookTitle = document.createElement("h3");
    bookTitle.innerText = bookObject.title;
    bookTitle.setAttribute("data-testid", "bookItemTitle");

    const bookAuthor = document.createElement("p");
    bookAuthor.innerText = `Penulis: ${bookObject.author}`;
    bookAuthor.setAttribute("data-testid", "bookItemAuthor");

    const bookYear = document.createElement("p");
    bookYear.innerText = `Tahun: ${bookObject.year}`;
    bookYear.setAttribute("data-testid", "bookItemYear");

    const container = document.createElement("div");
    container.append(bookTitle, bookAuthor, bookYear);
    container.setAttribute("data-bookid", bookObject.id);
    container.setAttribute("data-testid", "bookItem");

    const actionContainer = document.createElement("div");

    const deleteButton = document.createElement("button");
    deleteButton.innerText = "Hapus Buku";
    deleteButton.setAttribute("data-testid", "bookItemDeleteButton");
    deleteButton.addEventListener("click", function () {
      removeBook(bookObject.id);
    });

    const editButton = document.createElement("button");
    editButton.innerText = "Edit Buku";
    editButton.setAttribute("data-testid", "bookItemEditButton");
    // Tambahkan fungsi edit bila diperlukan

    actionContainer.append(deleteButton, editButton);

    if (bookObject.isComplete) {
      const unreadButton = document.createElement("button");
      unreadButton.innerText = "Belum selesai dibaca";
      unreadButton.setAttribute("data-testid", "bookItemIsCompleteButton");
      unreadButton.addEventListener("click", function () {
        undoBookFromCompleted(bookObject.id);
      });

      actionContainer.append(unreadButton);
    } else {
      const completeButton = document.createElement("button");
      completeButton.innerText = "Selesai dibaca";
      completeButton.setAttribute("data-testid", "bookItemIsCompleteButton");
      completeButton.addEventListener("click", function () {
        addBookToCompleted(bookObject.id);
      });

      actionContainer.append(completeButton);
    }

    container.append(actionContainer);

    return container;
  }

  // Fungsi untuk menghapus buku
  function removeBook(bookId) {
    const bookIndex = findBookIndex(bookId);
    if (bookIndex === -1) return;

    books.splice(bookIndex, 1);
    saveBooksToStorage(); // Simpan perubahan ke localStorage

    document.dispatchEvent(new Event(RENDER_EVENT));
  }

  // Fungsi untuk memindahkan buku ke daftar selesai dibaca
  function addBookToCompleted(bookId) {
    const bookTarget = findBook(bookId);
    if (bookTarget == null) return;

    bookTarget.isComplete = true;
    saveBooksToStorage(); // Simpan perubahan ke localStorage

    document.dispatchEvent(new Event(RENDER_EVENT));
  }

  // Fungsi untuk memindahkan buku dari daftar selesai ke belum selesai
  function undoBookFromCompleted(bookId) {
    const bookTarget = findBook(bookId);
    if (bookTarget == null) return;

    bookTarget.isComplete = false;
    saveBooksToStorage(); // Simpan perubahan ke localStorage

    document.dispatchEvent(new Event(RENDER_EVENT));
  }

  // Fungsi untuk mencari buku berdasarkan ID
  function findBook(bookId) {
    for (const bookItem of books) {
      if (bookItem.id === bookId) {
        return bookItem;
      }
    }
    return null;
  }

  // Fungsi untuk mencari index buku
  function findBookIndex(bookId) {
    for (const index in books) {
      if (books[index].id === bookId) {
        return index;
      }
    }
    return -1;
  }

  // Event listener untuk penambahan buku
  document.getElementById("bookForm").addEventListener("submit", function (event) {
    event.preventDefault();
    addBook();
  });

  // Event listener untuk render ulang daftar buku
  document.addEventListener(RENDER_EVENT, function () {
    incompleteBookList.innerHTML = "";
    completeBookList.innerHTML = "";

    for (const bookItem of books) {
      const bookElement = makeBook(bookItem);
      if (!bookItem.isComplete) {
        incompleteBookList.append(bookElement);
      } else {
        completeBookList.append(bookElement);
      }
    }
  });

  // Render ulang daftar buku saat halaman dimuat
  document.dispatchEvent(new Event(RENDER_EVENT));

  // Event listener untuk pencarian buku
  document.getElementById("searchBook").addEventListener("submit", function (event) {
    event.preventDefault();
    const searchTitle = document.getElementById("searchBookTitle").value.toLowerCase();

    incompleteBookList.innerHTML = "";
    completeBookList.innerHTML = "";

    for (const bookItem of books) {
      if (bookItem.title.toLowerCase().includes(searchTitle)) {
        const bookElement = makeBook(bookItem);
        if (!bookItem.isComplete) {
          incompleteBookList.append(bookElement);
        } else {
          completeBookList.append(bookElement);
        }
      }
    }
  });
});
